# IndicatorLights
KSP mod that adds LED-like "indicator lights" for various uses.

Currently in a pre-release state, use at your own risk.
