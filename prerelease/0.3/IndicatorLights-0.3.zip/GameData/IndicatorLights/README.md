# IndicatorLights
KSP mod that adds LED-like "indicator lights" for various uses.

Currently in a pre-release state, use at your own risk. Mostly what this means is
that I reserve the right to make breaking changes if necessary. (I try not to,
it's just that I'm not making any promises).

Current functionality included with this mod:

* An "indicator lamp" that toggles on/off with action groups and has customizable on/off colors in the editor
* On/off indicator lights on fuel cells

Lots more planned, that's just what's there so far!

